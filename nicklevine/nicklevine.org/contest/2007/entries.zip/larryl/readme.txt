20070104 first stab at decoding keyword to geo cards
20070205 minimal continuo implementation works, but probably bugridden.
20070206 neural network evolver works. ANN player works, can choose
         between random or ann brain.
20070208 fixed or trimmed ann evolver
20070208 removed bugs, added a minimal test suit
20070214 ann5 contains anns learned by using the deck one time and 10 first cards.
20070215 ann6 contains anns learned by using the same deck 10 times.
         going through all cards

