# $Id: //info.ravenbrook.com/user/ndl/lisp/claude/claude-1.0.2/mumble/pyMumble/__init__.py#1 $
# A stub file allowing a Python in ../ to say "from pyMumble import mumble" etc.
# NDL 2013-03-18.
