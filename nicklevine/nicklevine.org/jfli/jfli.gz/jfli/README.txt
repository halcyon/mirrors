       JFLI - a Java Foreign Language Interface for Common Lisp
       ========================================================

                             Version 0.2


1. License

The use and distribution terms for this software are covered by the
Common Public License 1.0, which can be found in the file CPL.TXT at
the root of this distribution. By using this software in any fashion,
you are agreeing to be bound by the terms of this license. You must
not remove this notice, or any other, from this software.


2. Documentation

See the file docs/jfli.html


3. History

jfli was written by Rich Hickey in 2004. It was updated by Nick Levine
in 2008.

The original version was "unnumbered", so let's retrospectively call
that 0.1, which makes the current version 0.2.

What's changed in 0.2:

 - a nunber of significant memory leaks have been plugged

 - there's better support for system building

 - configurable exception handling

 - JFLI package now exports box-int, unbox-int (as documented) -- it
   previously exported box-integer, unbox-integer which did nothing

 - *pvm* and *penv* are now defvars, so you can reload jni.lisp

 - documentation reflects all API-visible changes plus some minor
   cleanups


4. Known problems in 0.2:

 - Threading is one area of jfli which needs more attention. The JNI
   call DetachCurrentThread has proved most problematic (SEGVs in
   foriegn code, random corruption in Java internals and heaven only
   knows what else) and so we need another solution to prevent used
   threads from "leaking". The solution proposed, to recycle lisp
   threads rather than letting them go, is implemented in the file
   process.lisp which can be used as a standalone facility
   independently of the jfli.

 - There have been problems with callbacks into lisp: crashes
   attributed to multiple simultaneous invocation of the callback.

 - jfli treats null characters as string terminators even though Java
   does not.

 - Defect affecting only 32-bit x86 platforms running Linux, FreeBSD
   or Mac OS X (not Windows). Fixed in LispWorks 5.1; patched (for LWL
   5.0 anyway) under Lisp Support Call #35725.

   Occurances of java.lang.NullPointerException,
   java.lang.ArrayIndexOutOfBoundsException, etc which have no
   explanation even after reading Sun Java sources.

   This turns out to be caused by a bug in the FLI, which can leave
   the CPU's direction flag set incorrectly in some cases. When the
   direction flag is set incorrectly, some optimized memory copying
   routines will corrupt adjacent objects.


jfli copyright 2004 (c) Rich Hickey. All rights reserved.
Updates copyright 2008 (c) Nick Levine. All rights reserved.
