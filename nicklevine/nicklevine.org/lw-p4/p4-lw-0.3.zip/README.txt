	LISPWORKS / P4 BINDING

To load this package, load the file "load.lisp" in this directory.

You then have the following bindings (as in p4.el):

   control-x p e           "P4 Edit"
   control-x p S           "P4 Submit"
   control-x p o           "P4 Opened"
   control-x p r           "P4 Revert"


My purpose in writing this was to give me a simple integration between
LispWorks and the Perforce SCM, enough to cut out (say) 90% of the
context switches in return for 10% of the programming effort. I might
come back and do the rest some time.

Please read and take note of the "fitness for use" statement below,
and keep a careful eye out for problems. Feel free to report defects
and to submit suggestions (or even improvments), to
ndl@ravenbrook.com.


RELEASE HISTORY

0.3  2014-03-05

- No longer uses COM; not restricted to Windows

0.2  2008-04-22 

- Improved presentation for "p4 opened"
- Add "p4 revert"
- Process P4CONFIG file
- Improved support for filenames containing spaces
- Incorporates latest version of p4com.dll from public.perforce.com

0.1  2003-11-12 

- Initial release as "P4COM", on Windows only






COPYRIGHT AND LICENCE

This file is copyright (c) 2003 - 2014, Nick Levine.  All rights
reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

1.  Redistributions of source code must retain the above copyright
    notice, this list of conditions and the following disclaimer.

2.  Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions and the following disclaimer in
    the documentation and/or other materials provided with the
    distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
HOLDERS AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.


$Id: //info.ravenbrook.com/user/ndl/lisp/lw-p4/README.txt#1 $